package lib;

public class PrimeiraFase implements Fase {
	
	@Override
	public int getPontuacao() {
		return 1;
	}
}
