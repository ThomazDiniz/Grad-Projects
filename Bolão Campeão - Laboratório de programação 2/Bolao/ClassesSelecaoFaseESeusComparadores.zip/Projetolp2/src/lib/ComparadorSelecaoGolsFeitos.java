package lib;

import java.util.Comparator;

public class ComparadorSelecaoGolsFeitos implements Comparator<Selecao>{

	@Override
	public int compare(Selecao s1, Selecao s2) {
		return s1.getGolsFeitos() - s2.getGolsFeitos();
	}
}
