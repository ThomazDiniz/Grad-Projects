package lib;

public interface Fase {
	
	public int getPontuacao();

}
