package lib;

import java.util.Comparator;

public class ComparadorSelecaoSaldoDeGols implements Comparator<Selecao>{

	@Override
	public int compare(Selecao s1, Selecao s2) {
		return s1.calculaSaldoDeGols() - s2.calculaSaldoDeGols();
	}
}
