package lib;

public class QuintaFase implements Fase{

	@Override
	public int getPontuacao() {
		return 16;
	}
}
