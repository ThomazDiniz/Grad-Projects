package lib;

import java.io.Serializable;

public class Selecao implements Serializable{

	private static final long serialVersionUID = 5065590040554842084L;
	private String NomeDaSelecao;
	private int NumVitorias;
	private int NumEmpates;
	private int NumDerrotas;
	private int NumGolsSofridos;
	private int NumGolsFeitos;
	private int NumJogosAteOMomento;
	private boolean SelecaoEliminada;
	  
	//Devo lançar exceção, caso o 'nome' passado como parâmetro não conste com os times que participarão da copa;
	//Falta a imagem no construtor;
	public Selecao (String nome) throws DadoInvalidoException{
		if (nome == "" || nome == null){
			throw new DadoInvalidoException("Nome de selecao invalida.");
		}
		
		this.NomeDaSelecao = nome;
		this.NumVitorias = 0;
		this.NumDerrotas = 0;
		this.NumEmpates = 0;
		this.NumGolsSofridos = 0;
		this.NumGolsFeitos = 0;
		this.NumJogosAteOMomento = 0;
		this.SelecaoEliminada = false;
	}
	
	public String getNome(){
		return NomeDaSelecao;
	}

	public int getVitorias(){
		return NumVitorias;
	}
	
	public void adicionaVitoria(){
		NumVitorias++;
	}
	
	public int getDerrotas(){
		return NumDerrotas; 
	}
	
	public void adicionaDerrota(){
		NumDerrotas++;
	}
	
	public int getEmpates(){
		return NumEmpates;
	}
	
	public void adicionaEmpate(){
		NumEmpates++;
	}
	
	public int getGolsSofridos(){
		return NumGolsSofridos;
	}
	
	//Lançar exceção para o caso do número 'n' passado como parâmetro ser negativo;
	public void setGolsSofridos(int n) throws DadoInvalidoException{
		if (n<0){
			throw new DadoInvalidoException("Numero de gols invalido.");
		}
		NumGolsSofridos += n;
	}
	
	public int getGolsFeitos(){
		return NumGolsFeitos;
	}
	
	//Lançar exceção para o caso do número 'n' passado como parâmetro ser negativo;
	public void setGolsFeitos(int n) throws DadoInvalidoException{
		if (n<0){
			throw new DadoInvalidoException("Numero de gols invalido.");
		}
		
		NumGolsFeitos += n;
	}
	
	public int getJogosAteAgora(){
		return NumJogosAteOMomento;
	}
	
	public void setJogosAteAgora(){
		NumJogosAteOMomento++;
	}
	
	//Mudar nome do método, para ficar mais 'OO';
	public void setSelecaoEliminada(){
		SelecaoEliminada = true;
	}
	
	public int calculaFase(){
		if (NumJogosAteOMomento <= 3){
			return 1; //Primeira fase
		}
		
		else if (NumJogosAteOMomento == 4){
			return 2; // Oitavas de final
		}
		
		else if (NumJogosAteOMomento == 5){
			return 3; // Quartas de final
		}
		
		else if (NumJogosAteOMomento == 6){
			return 4; //SemiFinal
		}
		
		else if (NumJogosAteOMomento == 7){
			return 5; //Final
		}
		
		return 0;
	}
	
	public int calculaSaldoDeGols(){
		return NumGolsFeitos - NumGolsSofridos;
	}
	
	public int calculaPercentualVitorias(){
		return ((NumVitorias/NumJogosAteOMomento)*100);                                
	}
	
	public int calculaPercentualEmpates(){
		return ((NumEmpates/NumJogosAteOMomento)*100);                                 
	}
	
	public int calculaPercentualDerrotas(){
		return ((NumDerrotas/NumJogosAteOMomento)*100);                                 
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((NomeDaSelecao == null) ? 0 : NomeDaSelecao.hashCode());
		result = prime * result + NumDerrotas;
		result = prime * result + NumEmpates;
		result = prime * result + NumGolsFeitos;
		result = prime * result + NumGolsSofridos;
		result = prime * result + NumJogosAteOMomento;
		result = prime * result + NumVitorias;
		result = prime * result + (SelecaoEliminada ? 1231 : 1237);
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Selecao other = (Selecao) obj;
		if (NomeDaSelecao == null) {
			if (other.NomeDaSelecao != null)
				return false;
		} else if (!NomeDaSelecao.equals(other.NomeDaSelecao))
			return false;
		if (NumDerrotas != other.NumDerrotas)
			return false;
		if (NumEmpates != other.NumEmpates)
			return false;
		if (NumGolsFeitos != other.NumGolsFeitos)
			return false;
		if (NumGolsSofridos != other.NumGolsSofridos)
			return false;
		if (NumJogosAteOMomento != other.NumJogosAteOMomento)
			return false;
		if (NumVitorias != other.NumVitorias)
			return false;
		if (SelecaoEliminada != other.SelecaoEliminada)
			return false;
		return true;
	}
	
	
}
