package lib;

public class SegundaFase implements Fase{

	@Override
	public int getPontuacao() {
		return 2;
	}
}
