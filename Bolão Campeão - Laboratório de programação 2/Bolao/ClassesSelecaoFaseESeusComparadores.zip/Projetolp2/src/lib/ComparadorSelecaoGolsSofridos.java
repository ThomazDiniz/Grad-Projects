package lib;

import java.util.Comparator;

public class ComparadorSelecaoGolsSofridos implements Comparator<Selecao>{

	@Override
	public int compare(Selecao s1, Selecao s2) {
		return s1.getGolsSofridos() - s2.getGolsSofridos();
	}
}
