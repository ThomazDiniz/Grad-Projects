package lib;

public class QuartaFase implements Fase{

	@Override
	public int getPontuacao() {
		return 8;
	}	
}
