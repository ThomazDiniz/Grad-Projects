package lib;

import java.util.Comparator;

public class ComparadorSelecaoDerrotas implements Comparator<Selecao>{

	@Override
	public int compare(Selecao s1, Selecao s2) {
		return s1.getDerrotas() - s2.getDerrotas();
	}

}
