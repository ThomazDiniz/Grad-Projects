package lib;

public class TerceiraFase implements Fase{

	@Override
	public int getPontuacao() {
		return 4;
	}
}
